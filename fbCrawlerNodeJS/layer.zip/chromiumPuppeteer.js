const chromium = require('./nodejs/node_modules/chrome-aws-lambda/build');

exports.puppeteer = async function () {
    const browser = await chromium.puppeteer.launch({
        args: chromium.args,
        defaultViewport: chromium.defaultViewport,
        executablePath: await chromium.executablePath,
        headless: chromium.headless,
        ignoreHTTPSErrors: true,
    });

    return browser;
};

exports.healthcheck = function () {
    return "Puppeteer is working!";
};